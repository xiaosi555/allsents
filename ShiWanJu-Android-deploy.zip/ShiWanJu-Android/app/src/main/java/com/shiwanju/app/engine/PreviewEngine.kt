package com.shiwanju.app.engine

import com.shiwanju.app.data.AppData
import com.shiwanju.app.data.HistoryEntry
import com.shiwanju.app.data.UiState
import com.shiwanju.app.data.layoutKindOf
import com.shiwanju.app.engine.TextUtil.esc
import com.shiwanju.app.engine.TextUtil.pad2
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode

/**
 * 排版引擎：把“版式模板 + 文案 + 配图 + 动图 + 往期 + 账号头像”渲染为预览 HTML。
 * 是 Web 版 buildPreview / fillUnit / updatePreview 的 Jsoup 等价实现。
 */
object PreviewEngine {
    private val TEXT_SKIP = Regex("^(PART|[“”\"'‘’「」『』]+)$")
    private val NUM = Regex("^\\d{1,3}$")
    private val MIN_AGO = Regex("^\\d+分钟前$")
    private val WIDTH_PX = Regex("width:\\s*(\\d+)px")

    private class Ctx(val data: AppData, val ui: UiState, val doc: Document) {
        val layoutIdx: Int = layoutIndex(data, ui)
        val layoutName: String = data.layout.getOrNull(layoutIdx)?.name ?: ""
        val kind: String = layoutKindOf(layoutName)
        val account = data.accounts.firstOrNull { it.id == ui.accountId } ?: data.accounts.firstOrNull()
    }

    fun layoutIndex(data: AppData, ui: UiState): Int {
        val i = data.layout.indexOfFirst { it.id == ui.layoutId }
        return if (i >= 0) i else if (data.layout.isEmpty()) -1 else 0
    }

    /** 往期 / 动图共用边距（上右下左）的默认值：按版式种类 */
    fun defaultMargins(kind: String): List<Int> = when (kind) {
        "moments" -> listOf(25, 25, 0, 55)
        "duan" -> listOf(16, 15, 16, 15)
        else -> listOf(16, 0, 16, 0)
    }

    fun margins(ui: UiState, kind: String): List<Int> =
        ui.margins[kind.ifEmpty { "default" }]?.takeIf { it.size == 4 } ?: defaultMargins(kind)

    private fun newDoc(): Document {
        val d = Jsoup.parseBodyFragment("")
        d.outputSettings().prettyPrint(false)
        return d
    }

    private fun fragment(html: String?): List<Node> {
        val d = Jsoup.parseBodyFragment(html ?: "")
        d.select("script").remove()
        return d.body().childNodes().toList()
    }

    private fun setMargin(el: Element, m: List<Int>) {
        listOf("top", "right", "bottom", "left").forEachIndexed { i, s -> Css.set(el, "margin-$s", "${m[i]}px", true) }
    }

    private fun htmlBlock(ctx: Ctx, content: String?): Element {
        val div = ctx.doc.createElement("div")
        div.attr("style", "width:100%; background:#ffffff; box-sizing:border-box;")
        div.appendChildren(fragment(content))
        return div
    }

    /** 渲染预览区域的内部 HTML */
    fun render(data: AppData, ui: UiState): String {
        val doc = newDoc()
        val ctx = Ctx(data, ui, doc)
        val body = doc.body()
        val gif = data.files.gif.firstOrNull { it.id == ui.gifId }
        val hist = ui.historyIds.mapNotNull { id -> data.history.firstOrNull { it.id == id } }
        val blocks = LinkedHashMap<String, Element>()
        val m = margins(ui, ctx.kind)

        if (ctx.layoutIdx >= 0) body.appendChild(buildPreview(ctx, data.layout[ctx.layoutIdx].content))
        if (hist.isNotEmpty()) {
            val h = htmlBlock(ctx, buildHistoryHtml(hist))
            h.attr("data-preview-history", "true")
            Css.set(h, "width", "auto"); Css.set(h, "max-width", "100%")
            setMargin(h, m)
            blocks["history"] = h
        }
        if (gif != null) {
            val g = htmlBlock(ctx, ui.gifContent.ifEmpty { gif.content })
            g.attr("data-preview-gif", "true")
            Css.set(g, "display", "block"); Css.set(g, "clear", "both"); Css.set(g, "width", "auto"); Css.set(g, "max-width", "100%")
            setMargin(g, m)
            g.select("[contenteditable=false]").forEach { it.removeAttr("contenteditable") }   // 动图内容里的“不可编辑”统一放开
            g.select("img").forEach { it.attr("draggable", "false") }
            blocks["gif"] = g
        }
        // 动图 / 往期按点击先后顺序插入（已选未记录顺序的按 往期→动图 补齐）
        val order = ui.mediaOrder.filter { blocks.containsKey(it) }.distinct().toMutableList()
        listOf("history", "gif").forEach { if (blocks.containsKey(it) && it !in order) order.add(it) }
        order.forEach { body.appendChild(blocks.getValue(it)) }

        if (body.childNodeSize() == 0) return "<div style=\"padding:40px 20px; text-align:center; color:#999; font-size:13px;\">暂无版式，请到【我的】中添加</div>"

        // 断章序引版：正文统一深灰色，序号（#999）保持原色
        if (ctx.kind == "duan") {
            body.select("*").forEach { el ->
                if (el.children().isEmpty() && el.text().isNotBlank()) {
                    var inNumber = false
                    var p: Element? = el
                    while (p != null) { if (p.tagName() == "p" && p.attr("style").contains("#999")) { inNumber = true; break }; p = p.parent() }
                    if (!inNumber) Css.set(el, "color", "#333333", true)
                }
            }
        }
        return body.html()
    }

    // ---------------------------------------------------------------- 版式单元重复

    private fun periodOf(list: List<Element>): Int {
        val n = list.size
        for (p in 1..n) {
            if (n % p != 0) continue
            if ((0 until n).all { list[it].tagName() == list[it % p].tagName() }) return p
        }
        return n
    }

    private fun buildPreview(ctx: Ctx, content: String?): Element {
        val frag = Jsoup.parseBodyFragment(content ?: "")
        frag.select("script").remove()
        val top = frag.body().children().toList()
        val styles = top.filter { it.tagName() == "style" }
        var nodes = top.filter { it.tagName() != "style" }

        // 单个外层容器：内部只有 1 个单元 / 或由重复单元构成 → 外层作为容器，内部单元重复
        var wrapper: Element? = null
        if (nodes.size == 1) {
            val kids = nodes[0].children().filter { it.tagName() != "style" }
            if (kids.size == 1 || (kids.size >= 2 && periodOf(kids) < kids.size)) { wrapper = nodes[0]; nodes = kids }
        }
        val n = nodes.size
        val k = if (n > 0) periodOf(nodes) else 0
        val unitList = ArrayList<List<Element>>()
        var s = 0
        while (k > 0 && s + k <= n) { unitList.add(nodes.subList(s, s + k)); s += k }
        if (unitList.isEmpty()) unitList.add(nodes)

        val ui = ctx.ui
        val copy = ui.copyLines
        val pool = ui.imgPool
        val hasCopy = copy.isNotEmpty()
        val q = maxOf(1, ui.quantity)
        val total = if (hasCopy) minOf(q, copy.size) else minOf(q, unitList.size)

        // 选中文案后，按字符数由少到多排序（正文字数，不含出处），预览按此顺序输出
        val ordered = if (hasCopy)
            copy.take(total).mapIndexed { idx, l -> TextUtil.parseSource(l).copy(idx = idx) }
                .sortedWith(compareBy({ TextUtil.charLen(it.body) }, { it.idx }))
        else emptyList()

        val out = ctx.doc.createElement("div")
        val host: Element
        if (wrapper != null) { host = wrapper.shallowClone(); out.appendChild(host) }
        else { host = out; out.attr("style", "width:100%; margin:0; padding:0; background:#ffffff; box-sizing:border-box;") }
        styles.forEach { host.appendChild(it.clone()) }

        val mul = ui.multiplier.coerceIn(1, 5)
        for (i in 0 until total) {
            val clones = unitList[i % unitList.size].map { it.clone() }
            // 倍率：每个条目共 mul 句，额外的句子取自文案池，用两个换行分隔追加
            val extras = ArrayList<String>()
            if (hasCopy) for (j in 1 until mul) extras.add(TextUtil.parseSource(copy[(total * j + i) % copy.size]).body)
            fillUnit(ctx, clones, i, if (hasCopy) ordered[i] else null, if (pool.isNotEmpty()) pool[i % pool.size] else null, extras)
            applyAccountAvatar(ctx, clones)
            squareMomentImages(ctx, clones)
            clones.forEach { it.attr("data-unit", i.toString()) }
            if (i < total - 1 && clones.isNotEmpty()) Css.set(clones.last(), "margin-bottom", "25px", true)   // 条目之间统一 25px
            if (i == total - 1) trimTrailingSpace(ctx, clones)
            clones.forEach { host.appendChild(it) }
        }
        if (ui.previewEmoji.isNotEmpty()) appendEmojiToNumbers(ctx, host, ui.previewEmoji)
        return out
    }

    /** 最后一个条目去掉尾部间距（含断章序引末尾的空白占位段落），让往期 / 动图的上边距直接决定块间距 */
    private fun trimTrailingSpace(ctx: Ctx, clones: List<Element>) {
        val last = clones.lastOrNull() ?: return
        Css.set(last, "margin-bottom", "0", true)
        if (ctx.kind == "duan") {
            val tail = last.children().filter { it.tagName() == "p" }.lastOrNull()
            if (tail != null && tail.text().isBlank() && tail.select("br").isNotEmpty()) Css.set(tail, "display", "none", true)
        }
    }

    // ---------------------------------------------------------------- 填充单元

    private fun textNodes(roots: List<Element>): List<TextNode> {
        val out = ArrayList<TextNode>()
        roots.forEach { r -> r.traverse { node, _ -> if (node is TextNode && !node.isBlank) out.add(node) } }
        return out
    }

    private fun imgsOf(root: Element): List<Element> = if (root.tagName() == "img") listOf(root) else root.select("img").toList()

    private fun fillUnit(ctx: Ctx, nodes: List<Element>, i: Int, line: TextUtil.Parsed?, img: String?, extras: List<String>) {
        val cands = ArrayList<TextNode>()
        textNodes(nodes).forEach { n ->
            val whole = n.wholeText
            val t = whole.trim()
            when {
                NUM.matches(t) -> if (line != null) n.text(whole.replaceFirst(t, pad2(i + 1)))          // 序号 01、02…
                MIN_AGO.matches(t) -> if (line != null) n.text(whole.replaceFirst(t, "${i + 1}分钟前"))   // 朋友圈“N分钟前”
                !TEXT_SKIP.matches(t) -> cands.add(n)
                else -> {}
            }
        }
        if (line != null && cands.isNotEmpty()) {
            // 正文 = 不含《》的最长文本
            var qi = -1; var max = -1
            cands.forEachIndexed { idx, n ->
                val t = n.wholeText.trim()
                if (t.contains('《')) return@forEachIndexed
                if (t.length > max) { max = t.length; qi = idx }
            }
            if (qi < 0) qi = 0
            val srcNode = cands.getOrNull(qi + 1)
            cands[qi].text(line.body)
            if (srcNode != null) applySource(ctx, srcNode, line.source)   // 出处按各版式固定模板输出（朋友圈不展示）
            appendExtras(ctx, cands[qi], extras)
        }
        if (img != null) {
            nodes.forEach { root ->
                imgsOf(root).forEach { im ->
                    val w = WIDTH_PX.find(im.attr("style"))
                    if (w != null && w.groupValues[1].toInt() <= 64) return@forEach   // 头像不替换
                    setPreviewImage(im, img)
                }
            }
        }
    }

    /** 预览用图片：http 升级为 https；失败回退原地址；关闭 Referer 绕过防盗链 */
    private fun setPreviewImage(im: Element, url: String) {
        val shown = url.replace(Regex("^http://", RegexOption.IGNORE_CASE), "https://")
        im.attr("referrerpolicy", "no-referrer")
        im.attr("data-fallback-src", if (url != shown) url else "")
        im.attr("onerror", "this.onerror=null;var f=this.getAttribute('data-fallback-src');if(f)this.src=f;")
        im.attr("src", shown)
        im.removeAttr("srcset"); im.removeAttr("loading")
    }

    /** 朋友圈版：内容图片显示为正方形（头像除外） */
    private fun squareMomentImages(ctx: Ctx, nodes: List<Element>) {
        if (ctx.kind != "moments") return
        nodes.forEach { root ->
            imgsOf(root).forEach { im ->
                val w = WIDTH_PX.find(im.attr("style"))
                if (w != null && w.groupValues[1].toInt() <= 64) return@forEach
                Css.set(im, "aspect-ratio", "1 / 1", true)
                Css.set(im, "object-fit", "cover", true)
                Css.set(im, "height", if (w != null) "${w.groupValues[1]}px" else "auto", true)
            }
        }
    }

    /** 朋友圈版：头像取自当前选中账号（微信头像链接），失败时回退到版式自带头像 */
    private fun applyAccountAvatar(ctx: Ctx, nodes: List<Element>) {
        if (ctx.kind != "moments") return
        var url = ctx.account?.avatar?.trim() ?: ""
        if (!Regex("^(https?:)?//", RegexOption.IGNORE_CASE).containsMatchIn(url) && !url.startsWith("data:image/", true)) return
        url = url.replace(Regex("^http://((?:thirdwx\\.|wx\\.)?qlogo\\.cn)", RegexOption.IGNORE_CASE), "https://$1")
        nodes.forEach { root ->
            imgsOf(root).forEach { im ->
                val w = WIDTH_PX.find(im.attr("style"))
                if (!(w != null && w.groupValues[1].toInt() <= 64)) return@forEach
                im.attr("data-fallback-src", im.attr("src"))
                im.attr("referrerpolicy", "no-referrer")
                im.attr("onerror", "this.onerror=null;var f=this.getAttribute('data-fallback-src');if(f)this.src=f;")
                im.attr("src", url)
                im.removeAttr("srcset")
            }
        }
    }

    // ---------------------------------------------------------------- 出处 / 倍率

    private fun ancestors(node: Node): Sequence<Element> = generateSequence(node.parent() as? Element) { it.parent() }

    private fun sourceTemplate(kind: String, text: String): String {
        val t = esc(text)
        return when (kind) {
            "sentence" -> "<span style=\"display:block!important;width:100%!important;margin:0!important;padding:0!important;\"><span leaf=\"\">$t</span></span>"
            "card" -> "<div style=\"width:100%;max-width:100%;margin:14px 0 0 0;padding:0;border:0;color:#999999;font-size:13px;line-height:2.1;overflow-wrap:anywhere;\">$t</div>"
            "duan" -> "<p style=\"margin: 0px; padding: 0px; box-sizing: border-box; visibility: visible;\"><strong style=\"box-sizing: border-box; visibility: visible;\"><span leaf=\"\" style=\"visibility: visible;\">$t</span></strong></p>"
            else -> ""
        }
    }

    private fun applySource(ctx: Ctx, srcNode: TextNode, source: String) {
        val kind = ctx.kind
        val host: Element? = when (kind) {
            "sentence" -> ancestors(srcNode).firstOrNull { it.tagName() == "span" && Css.has(it, Regex("display\\s*:\\s*block", RegexOption.IGNORE_CASE)) }
            "card" -> ancestors(srcNode).firstOrNull { it.tagName() == "div" && Css.has(it, Regex("overflow-wrap", RegexOption.IGNORE_CASE)) }
            "duan" -> ancestors(srcNode).firstOrNull { it.tagName() == "p" }
            else -> null
        }
        if (host == null) { srcNode.text(""); return }
        if (kind == "moments" || source.isEmpty()) {
            // 无出处 / 朋友圈：移除出处元素（断章序引同时移除其上方的空白占位行）
            if (kind == "duan") {
                val prev = host.previousElementSibling()
                if (prev != null && prev.tagName() == "p" && prev.text().isBlank() && prev.select("br").isNotEmpty()) prev.remove()
            }
            host.remove()
            return
        }
        val repl = Jsoup.parseBodyFragment(sourceTemplate(kind, source)).body().child(0)
        host.replaceWith(repl)
    }

    /** 倍率：额外文案追加到各版式指定的容器内，两个换行分隔 */
    private fun appendExtras(ctx: Ctx, node: TextNode, extras: List<String>) {
        if (extras.isEmpty()) return
        val host = when (ctx.kind) {
            "card" -> ancestors(node).firstOrNull { Css.has(it, Regex("overflow-wrap\\s*:\\s*anywhere", RegexOption.IGNORE_CASE)) }
            "moments" -> ancestors(node).firstOrNull { Css.has(it, Regex("white-space\\s*:\\s*pre-wrap", RegexOption.IGNORE_CASE)) }
            "duan", "sentence" -> ancestors(node).firstOrNull { it.hasAttr("leaf") }
            else -> null
        } ?: (node.parent() as? Element) ?: return
        val pre = Css.has(host, Regex("white-space\\s*:\\s*pre", RegexOption.IGNORE_CASE))
        extras.forEach { t ->
            if (pre) host.appendText("\n\n$t")
            else { host.appendElement("br"); host.appendElement("br"); host.appendText(t) }
        }
    }

    // ---------------------------------------------------------------- 预览 emoji

    private fun makeEmoji(value: String): Element {
        val span = Element("span")
        span.attr("data-preview-emoji", "true")
        span.attr("style", "display:inline-block;width:1px;min-width:0;max-width:1px;height:1px;max-height:1px;overflow:hidden;vertical-align:middle;white-space:pre;word-break:normal;font-size:4px;line-height:5px;box-sizing:border-box;padding:0;margin:0;")
        span.appendText("    $value")
        return span
    }

    private fun appendEmojiToNumbers(ctx: Ctx, root: Element, value: String) {
        val addInside = { target: Element ->
            if (target.children().none { it.attr("data-preview-emoji") == "true" }) target.appendChild(makeEmoji(value))
        }
        val all = root.select("*").filter { it !== root }
        if (ctx.layoutName.contains("朋友圈")) {
            val targets = all.filter { it.children().isEmpty() && it.text().trim() == "拾万句" }   // 每个条目的昵称都插入
            targets.forEach(addInside)
            if (targets.isNotEmpty()) return
        }
        if (ctx.layoutName.contains("卡片")) {
            val targets = all.filter { it.children().isEmpty() && it.text().trim() == "“" }        // 每张卡片的左引号后
            targets.forEach(addInside)
            if (targets.isNotEmpty()) return
        }
        // 文字断句版、断章序引版：逐个动态序号后插入（01、02、03……）
        val nums = ArrayList<TextNode>()
        root.traverse { node, _ -> if (node is TextNode && Regex("^\\s*\\d{1,3}\\s*$").matches(node.wholeText) && !node.isBlank) nums.add(node) }
        nums.forEach { n ->
            val p = n.parent() as? Element ?: return@forEach
            if (p.attr("data-preview-emoji") == "true" || ancestors(n).any { it.attr("data-preview-emoji") == "true" }) return@forEach
            if (p.children().any { it.attr("data-preview-emoji") == "true" }) return@forEach
            n.after(makeEmoji(value))
        }
    }

    // ---------------------------------------------------------------- 往期

    private fun histImageCell(e: HistoryEntry): String {
        val img = "<img loading=\"lazy\" referrerpolicy=\"no-referrer\" src=\"${esc(e.image)}\" style=\"width:100%;aspect-ratio:1 / 1.15;border-radius:3px;object-fit:cover;display:block;background:#f5f5f5;\" />"
        val a = if (e.link.isNotEmpty()) "<a href=\"${esc(e.link)}\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"text-decoration:none;display:block;\">$img</a>" else img
        return a + "<p style=\"font-size:10px;color:#333;line-height:1.4;width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;margin:5px 0 0 0;padding:0;\">${esc(e.title.ifEmpty { e.name })}</p>"
    }

    private fun histTextLink(e: HistoryEntry): String {
        val t = esc(e.title.ifEmpty { e.name })
        return if (e.link.isNotEmpty())
            "<a href=\"${esc(e.link)}\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"color:#44546A !important;text-decoration:underline !important;font-size:12px !important;user-select:text !important;\">$t</a>"
        else "<span style=\"color:#44546A;font-size:12px;\">$t</span>"
    }

    /** 有图片 → 图片版（5 列等宽）；无图片 → 文字版；旧数据（无三项字段）按原内容代码输出 */
    fun buildHistoryHtml(entries: List<HistoryEntry>): String {
        val hasFields = { e: HistoryEntry -> e.title.isNotEmpty() || e.link.isNotEmpty() || e.image.isNotEmpty() }
        val imgs = entries.filter { it.image.isNotEmpty() }
        val texts = entries.filter { it.image.isEmpty() && hasFields(it) }
        val legacy = entries.filter { !hasFields(it) && it.content.isNotEmpty() }
        val sb = StringBuilder()
        if (imgs.isNotEmpty()) {
            val tds = StringBuilder()
            for (c in 0 until 5) tds.append("<td style=\"vertical-align:top;width:20%;padding:0 ${if (c < 4) 6 else 0}px 0 0;\">${imgs.getOrNull(c)?.let { histImageCell(it) } ?: ""}</td>")
            sb.append("<table style=\"width:100%;table-layout:fixed;border-collapse:collapse;border-spacing:0;margin:0;\"><tr>$tds</tr></table>")
        }
        texts.forEach { e -> sb.append("<p style=\"margin:${if (sb.isNotEmpty()) 8 else 0}px 0 0 0;padding:0;line-height:1.8;\">${histTextLink(e)}</p>") }
        legacy.forEach { sb.append(it.content) }
        return sb.toString()
    }

    /** 我的-更多-往期：保存条目时按模板生成渲染代码（与 Web 版 historyEntryHtml 一致） */
    fun historyEntryHtml(title: String, link: String, image: String): String {
        val t = esc(title); val l = esc(link); val im = esc(image)
        if (image.isNotEmpty()) {
            val img = "<img loading=\"lazy\" referrerpolicy=\"no-referrer\" src=\"$im\" style=\"width:100%;aspect-ratio:1 / 1.15;border-radius:3px;object-fit:cover;display:block;background:#f5f5f5;\" />"
            val a = if (link.isNotEmpty()) "<a href=\"$l\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"text-decoration:none;display:block;\">$img</a>" else img
            return a + "\n<p style=\"font-size:10px;color:#333;line-height:1.4;width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;margin:5px 0 0 0;padding:0;\">$t</p>"
        }
        return if (link.isNotEmpty())
            "<a href=\"$l\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"color:#44546A !important;text-decoration:underline !important;font-size:12px !important;user-select:text !important;\">$t</a>"
        else "<span style=\"color:#44546A;font-size:12px;\">$t</span>"
    }
}
