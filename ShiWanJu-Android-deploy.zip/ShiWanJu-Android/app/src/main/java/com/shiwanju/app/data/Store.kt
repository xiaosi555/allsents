package com.shiwanju.app.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonParser
import java.io.File

/** 本地持久化：数据存 filesDir/app_data.json；界面状态与偏好存 SharedPreferences。 */
class Store(private val ctx: Context) {
    private val gson: Gson = GsonBuilder().disableHtmlEscaping().create()
    private val pretty: Gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
    private val prefs = ctx.getSharedPreferences("shiwanju", Context.MODE_PRIVATE)
    private val dataFile get() = File(ctx.filesDir, "app_data.json")

    /** 各版式（卡片 / 断章序引 / 朋友圈 / 文字断句）的最新模板代码 */
    val templates: Map<String, String> by lazy {
        @Suppress("UNCHECKED_CAST")
        gson.fromJson(readAsset("templates.json"), Map::class.java) as Map<String, String>
    }

    private fun readAsset(name: String) = ctx.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun loadData(): AppData {
        val raw: AppData? = runCatching {
            if (dataFile.exists()) gson.fromJson(dataFile.readText(Charsets.UTF_8), AppData::class.java) else null
        }.getOrNull()
        val data = normalize(raw ?: gson.fromJson(readAsset("seed.json"), AppData::class.java))
        if (raw == null) saveData(data)
        return data
    }

    fun saveData(d: AppData) {
        runCatching { dataFile.writeText(gson.toJson(d), Charsets.UTF_8) }
    }

    fun exportJson(d: AppData): String = pretty.toJson(d)

    /** 解析备份：必须含 accounts 数组与 files 对象，否则返回 null（与 Web 版校验一致） */
    fun parseBackup(json: String): AppData? = runCatching {
        val o = JsonParser.parseString(json).asJsonObject
        if (!o.has("accounts") || !o.get("accounts").isJsonArray || !o.has("files") || !o.get("files").isJsonObject) return null
        normalize(gson.fromJson(json, AppData::class.java))
    }.getOrNull()

    /** 规范化：缺失 id 按顺序补确定性 id；文案类别非法时默认【朋友圈】；版式代码版本升级时更新各版式模板 */
    @Suppress("USELESS_ELVIS", "UNNECESSARY_SAFE_CALL")
    fun normalize(raw: AppData): AppData {
        fun <T> fill(list: List<T>?, prefix: String, getId: (T) -> String?, setId: (T, String) -> T): List<T> {
            val src = list ?: emptyList()
            val used = HashSet<String>()
            val out = ArrayList<T>()
            var n = 1
            for (item in src) {
                if (item == null) continue
                val id = getId(item)
                if (!id.isNullOrEmpty() && used.add(id)) { out.add(item); continue }
                var nid: String
                do { nid = prefix + "_" + (n++) } while (!used.add(nid))
                out.add(setId(item, nid))
            }
            return out
        }
        val files = raw.files ?: Files()
        var layout = fill(raw.layout, "layout", { it.id }, { x, i -> x.copy(id = i) })
            .map { it.copy(name = it.name ?: "", content = it.content ?: "") }
        var layoutVer = raw.layoutVer
        if (layoutVer != LAYOUT_VER) {
            layout = layout.map { l -> templates[layoutKindOf(l.name)]?.let { l.copy(content = it) } ?: l }
            layoutVer = LAYOUT_VER
        }
        return AppData(
            accounts = fill(raw.accounts, "acc", { it.id }, { x, i -> x.copy(id = i) })
                .map { it.copy(avatar = it.avatar ?: "", name = it.name ?: "", appId = it.appId ?: "", secret = it.secret ?: "", mpAvatar = it.mpAvatar ?: "", author = it.author ?: "") },
            layout = layout,
            history = fill(raw.history, "history", { it.id }, { x, i -> x.copy(id = i) })
                .map { it.copy(name = it.name ?: "", content = it.content ?: "", title = it.title ?: "", link = it.link ?: "", image = it.image ?: "") },
            emoji = fill(raw.emoji, "emoji", { it.id }, { x, i -> x.copy(id = i) })
                .map { it.copy(name = it.name ?: "", content = it.content ?: "") },
            files = Files(
                image = fill(files.image, "file_image", { it.id }, { x, i -> x.copy(id = i) }).map { it.copy(name = it.name ?: "", title = it.title ?: "", content = it.content ?: "") },
                text = fill(files.text, "file_text", { it.id }, { x, i -> x.copy(id = i) }).map {
                    it.copy(name = it.name ?: "", title = it.title ?: "", content = it.content ?: "",
                        category = if (it.category in TEXT_CATEGORIES) it.category else "朋友圈")
                },
                gif = fill(files.gif, "file_gif", { it.id }, { x, i -> x.copy(id = i) }).map { it.copy(name = it.name ?: "", title = it.title ?: "", content = it.content ?: "") }
            ),
            layoutVer = layoutVer
        )
    }

    // ---- 界面状态 ----
    fun loadUi(): UiState = runCatching {
        prefs.getString("ui_state", null)?.let { gson.fromJson(it, UiState::class.java) }
    }.getOrNull() ?: UiState()

    fun saveUi(u: UiState) { prefs.edit().putString("ui_state", gson.toJson(u)).apply() }

    // ---- 偏好：我的-文案 视图模式（list / grid），持久化直到下次切换 ----
    var textViewMode: String
        get() = prefs.getString("text_view_mode", "list") ?: "list"
        set(v) { prefs.edit().putString("text_view_mode", if (v == "grid") "grid" else "list").apply() }
}
