package com.shiwanju.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shiwanju.app.data.TEXT_CATEGORIES
import com.shiwanju.app.engine.TextUtil
import org.json.JSONObject

private val MAIN_TABS = listOf("account" to "账号", "layout" to "版式", "copy" to "文案", "image" to "配图", "more" to "更多")

/** 版式缩略图：按版式名称关键词匹配，未匹配则按顺序循环 */
private data class Thumb(val key: String, val color: Color, val bg: String)
private val THUMBS = listOf(
    Thumb("朋友圈", Color(0xFFCCFF00), "https://res.cloudinary.com/divete82s/image/upload/v1755071564/n2tnqdbb0dcvke4yhp3u.jpg"),
    Thumb("断章序引", Color(0xFFFF9900), "https://res.cloudinary.com/divete82s/image/upload/v1755068174/jxgekpcgycjbtncqxfwd.jpg"),
    Thumb("文字断句", Color(0xFF00FFFF), "https://res.cloudinary.com/divete82s/image/upload/v1755068146/uohviy9z57ae7guqovyf.jpg"),
    Thumb("卡片", Color(0xFFFF6699), "https://res.cloudinary.com/divete82s/image/upload/v1755068144/ybk7no0znhgdlmgcr1pv.jpg")
)
private fun thumbFor(name: String, index: Int) = THUMBS.firstOrNull { name.contains(it.key) } ?: THUMBS[index % THUMBS.size]
private fun shortName(name: String): String = name.replace(Regex("^\\s*\\d+\\s*[_\\-.、\\s]+\\s*"), "").ifEmpty { name }

@Composable
fun LayoutScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().background(AppColors.Bg).systemBarsPadding().imePadding()) {
        TopBar(vm)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            PreviewWebView(vm, Modifier.fillMaxSize())
            if (vm.editing) EditOverlay(vm)
        }
        BottomPanel(vm)
        MainNav(vm)
    }
}

// ---------------------------------------------------------------------- 顶部栏

@Composable
private fun TopBar(vm: AppViewModel) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("拾万句", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Text("${vm.charCount}字", color = AppColors.TextDim, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        ThemeChip("复制", false) {
            // 把当前预览作为富文本 HTML 复制到剪贴板（可直接粘贴进公众号编辑器）
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newHtmlText("拾万句", vm.previewHtml.replace(Regex("<[^>]+>"), ""), vm.previewHtml))
            vm.toast("已复制排版内容")
        }
        Spacer(Modifier.width(8.dp))
        ThemeChip(if (vm.editing) "完成" else "编辑", vm.editing) { vm.toggleEditing() }
    }
}

// ---------------------------------------------------------------------- 编辑悬浮窗

@Composable
private fun EditOverlay(vm: AppViewModel) {
    var front by remember { mutableStateOf("settings") }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val bw = with(LocalDensity.current) { maxWidth.toPx() }
        val bh = with(LocalDensity.current) { maxHeight.toPx() }

        // 编辑区左侧的入口图标
        Column(Modifier.align(Alignment.TopStart).padding(start = 6.dp, top = 130.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            EntryIcon("设", vm.showSettings) { vm.showSettings = !vm.showSettings; front = "settings" }
            EntryIcon("题", vm.showTitle) { vm.showTitle = !vm.showTitle; if (vm.showTitle) { vm.loadRandomTitle(); front = "title" } }
        }

        val order = if (front == "title") listOf("settings", "title") else listOf("title", "settings")
        order.forEach { id ->
            key(id) {
                if (id == "title" && vm.showTitle) TitleWindow(vm, bw, bh) { front = "title" }
                if (id == "settings" && vm.showSettings) SettingsWindow(vm, bw, bh) { front = "settings" }
            }
        }
    }
}

@Composable
private fun EntryIcon(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape)
            .background(if (active) AppColors.Theme else AppColors.Panel)
            .border(1.dp, AppColors.Theme.copy(alpha = 0.55f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (active) AppColors.OnTheme else AppColors.Theme, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun TitleWindow(vm: AppViewModel, bw: Float, bh: Float, onTouch: () -> Unit) {
    val clip = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { kotlinx.coroutines.delay(1200); copied = false } }
    FloatingWindow("随机标题", 60.dp, 70.dp, 270.dp, 170.dp, bw, bh, onClose = { vm.showTitle = false }, onTouch = onTouch) {
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF141414))
                .border(1.dp, Color(0xFF2C2C2C), RoundedCornerShape(8.dp)).padding(10.dp).verticalScroll(rememberScrollState())
        ) { Text(vm.titleText, color = Color.White, fontSize = 15.sp, lineHeight = 24.sp) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeChip(if (copied) "已复制" else "复制", true) { if (vm.hasTitle) { clip.setText(AnnotatedString(vm.titleText)); copied = true } }
            ThemeChip("换一个", false) { vm.loadRandomTitle() }
        }
    }
}

@Composable
private fun SettingsWindow(vm: AppViewModel, bw: Float, bh: Float, onTouch: () -> Unit) {
    FloatingWindow("编辑设置", 48.dp, 240.dp, 272.dp, 330.dp, bw, bh, onClose = { vm.showSettings = false }, onTouch = onTouch) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text("往期 / 动图边距（上 右 下 左，px）", color = AppColors.Theme, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            val m = vm.margins
            listOf(listOf(0 to "上", 1 to "右"), listOf(2 to "下", 3 to "左")).forEach { rowItems ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { (idx, label) ->
                        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, color = Color(0xFFBBBBBB), fontSize = 13.sp, modifier = Modifier.width(20.dp))
                            Stepper(m[idx], { vm.setMargin(idx, it) })
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("全局空行（以光标所在行为基准）", color = AppColors.Theme, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("内容上方插入空行", color = Color(0xFFBBBBBB), fontSize = 13.sp, modifier = Modifier.weight(1f))
                ThemeChip(if (vm.ui.blankTop) "开" else "关", vm.ui.blankTop) { vm.toggleBlank(true) }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("内容下方插入空行", color = Color(0xFFBBBBBB), fontSize = 13.sp, modifier = Modifier.weight(1f))
                ThemeChip(if (vm.ui.blankBottom) "开" else "关", vm.ui.blankBottom) { vm.toggleBlank(false) }
            }
            Text(vm.anchorLabel, color = Color(0xFF888888), fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

// ---------------------------------------------------------------------- 底部：二级面板 + 一级导航

@Composable
private fun BottomPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxWidth().height(168.dp).background(AppColors.Panel).padding(top = 6.dp)) {
        when (vm.ui.tab) {
            "account" -> AccountPanel(vm)
            "layout" -> LayoutPanel(vm)
            "copy" -> CopyPanel(vm)
            "image" -> ImagePanel(vm)
            "more" -> MorePanel(vm)
        }
    }
}

@Composable
private fun EmptyTip(text: String) {
    Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) { Text(text, color = AppColors.TextDim, fontSize = 13.sp, textAlign = TextAlign.Center) }
}

@Composable
private fun AccountPanel(vm: AppViewModel) {
    val accs = vm.data.accounts
    if (accs.isEmpty()) return EmptyTip("暂无账号，请到【我的】中添加")
    val sel = accs.indexOfFirst { it.id == vm.ui.accountId }.let { if (it < 0) 0 else it }
    LazyRow(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        items(accs.size) { i ->
            val a = accs[i]
            Column(
                Modifier.width(76.dp).height(92.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (i == sel) AppColors.Theme.copy(alpha = 0.16f) else AppColors.Field)
                    .border(1.dp, if (i == sel) AppColors.Theme else AppColors.Line, RoundedCornerShape(12.dp))
                    .clickable { vm.selectAccount(a.id) }.padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                AsyncImage(a.avatar, null, Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF333333)), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(6.dp))
                Text(a.name, color = if (i == sel) AppColors.Theme else AppColors.TextMain, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun LayoutPanel(vm: AppViewModel) {
    val list = vm.data.layout
    if (list.isEmpty()) return EmptyTip("暂无版式，请到【我的】中添加")
    val cur = vm.layoutIndex
    LazyRow(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        items(list.size) { i ->
            val l = list[i]; val t = thumbFor(l.name, i)
            Column(
                Modifier.width(92.dp).height(128.dp).clip(RoundedCornerShape(10.dp))
                    .border(2.dp, if (i == cur) AppColors.Theme else Color.Transparent, RoundedCornerShape(10.dp))
                    .clickable { vm.selectLayout(l.id) }
            ) {
                Box(Modifier.fillMaxWidth().height(30.dp).background(t.color), contentAlignment = Alignment.Center) {
                    Text(shortName(l.name), color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                AsyncImage(t.bg, null, Modifier.fillMaxWidth().weight(1f).background(Color(0xFF2A2A2A)), contentScale = ContentScale.Crop)
            }
        }
    }
}

/** 数量控件（3 / 6 / 9 / 自定义）+ 倍率 x1~x5 循环 —— 位于【文案】模块顶部右侧 */
@Composable
private fun QuantityControl(vm: AppViewModel) {
    val q = vm.ui.quantity
    var text by remember(q) { mutableStateOf(q.toString()) }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf(3, 6, 9).forEach { n -> MiniChip(n.toString(), q == n) { vm.setQuantity(n) } }
        Box(
            Modifier.width(54.dp).height(28.dp).clip(RoundedCornerShape(6.dp)).background(AppColors.Field).border(1.dp, AppColors.Line, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            BasicTextField(
                value = text, onValueChange = { v -> val d = v.filter { it.isDigit() }.take(2); text = d; d.toIntOrNull()?.let { vm.setQuantity(it) } },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                textStyle = TextStyle(color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center), cursorBrush = SolidColor(AppColors.Theme)
            )
        }
        Box(
            Modifier.height(28.dp).clip(RoundedCornerShape(6.dp)).border(1.dp, AppColors.Theme, RoundedCornerShape(6.dp))
                .clickable { vm.cycleMultiplier() }.padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) { Text("x${vm.ui.multiplier}", color = AppColors.Theme, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun MiniChip(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.defaultMinSize(minWidth = 28.dp).height(28.dp).clip(RoundedCornerShape(6.dp)).background(AppColors.Field)
            .border(1.dp, if (active) AppColors.Theme else AppColors.Line, RoundedCornerShape(6.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (active) AppColors.Theme else Color(0xFFCCCCCC), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun SubNavItem(text: String, active: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text, color = if (active) AppColors.Theme else AppColors.TextDim, fontSize = 14.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(20.dp).height(2.dp).background(if (active) AppColors.Theme else Color.Transparent))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GridCards(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun GridCard(text: String, active: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(8.dp)).background(AppColors.Field)
            .border(1.dp, if (active) AppColors.Theme else AppColors.Line, RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, color = if (active) AppColors.Theme else AppColors.TextMain, fontSize = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal) }
}

@Composable
private fun CopyPanel(vm: AppViewModel) {
    val cat = if (vm.ui.textCat in TEXT_CATEGORIES) vm.ui.textCat else TEXT_CATEGORIES[0]   // 顺序：朋友圈、名句
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { TEXT_CATEGORIES.forEach { c -> SubNavItem(c, c == cat) { vm.selectTextCat(c) } } }
        Spacer(Modifier.weight(1f))
        QuantityControl(vm)
    }
    val mods = vm.data.files.text.filter { it.category == cat }
    if (mods.isEmpty()) EmptyTip("【$cat】分类下暂无文案，可在【我的】-文案中添加")
    else GridCards { mods.forEach { m -> GridCard(m.name, m.id == vm.ui.copyModuleId) { vm.selectCopyModule(m.id) } } }
}

@Composable
private fun ImagePanel(vm: AppViewModel) {
    val pool = vm.ui.imgPool
    if (pool.isEmpty()) return EmptyTip("暂无配图，请到【我的】-更多-配图中添加")
    val m = vm.data.files.image.firstOrNull { it.id == vm.ui.imgModuleId }
    val used = minOf(vm.ui.quantity, pool.size)
    Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GridCard("重新随机") { vm.rerollImages() }
        Text("${m?.name ?: ""}\n备选 ${pool.size} 张", color = AppColors.TextDim, fontSize = 12.sp, lineHeight = 19.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(pool.size) { i ->
                AsyncImage(
                    pool[i], null,
                    Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF222222))
                        .border(2.dp, if (i < used) AppColors.Theme else Color.Transparent, RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            }
        }
    }
}

@Composable
private fun MorePanel(vm: AppViewModel) {
    val cats = listOf("emoji" to "emoji", "gif" to "动图", "history" to "往期")
    val cur = if (cats.any { it.first == vm.ui.moreCat }) vm.ui.moreCat else "gif"
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        cats.forEach { (k, label) -> SubNavItem(label, k == cur) { vm.setMoreCat(k) } }
    }
    when (cur) {
        "emoji" -> if (vm.data.emoji.isEmpty()) EmptyTip("暂无emoji，请到【我的】-更多-emoji中添加")
        else GridCards { vm.data.emoji.forEach { e -> GridCard(e.name.ifEmpty { "emoji" }) { vm.applyRandomEmoji() } } }
        "history" -> if (vm.data.history.isEmpty()) EmptyTip("暂无往期，请到【我的】-更多-往期中添加")
        else {
            val on = vm.ui.historyIds.isNotEmpty()
            GridCards {
                GridCard(if (on) "重新随机5条" else "随机5条", on) { vm.rollHistory() }
                if (on) GridCard("移除往期") { vm.clearHistory() }
                Text("共 ${vm.data.history.size} 条", color = AppColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
        else -> if (vm.data.files.gif.isEmpty()) EmptyTip("暂无动图，请到【我的】-更多-动图中添加")
        else GridCards { vm.data.files.gif.forEach { g -> GridCard(g.name, g.id == vm.ui.gifId) { vm.pickGif(g) } } }
    }
}

@Composable
private fun MainNav(vm: AppViewModel) {
    Row(Modifier.fillMaxWidth().height(52.dp).background(Color(0xFF0D0D0D))) {
        (MAIN_TABS + ("my" to "我的")).forEach { (k, label) ->
            val active = k == vm.ui.tab
            Box(
                Modifier.weight(1f).fillMaxHeight().clickable { if (k == "my") vm.screen = "my" else vm.switchTab(k) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (active) AppColors.Theme else Color(0xFF999999), fontSize = 14.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}
