package com.shiwanju.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.shiwanju.app.ui.AppViewModel
import com.shiwanju.app.ui.LayoutScreen
import com.shiwanju.app.ui.MyScreen
import com.shiwanju.app.ui.ShiWanJuTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // 排版页深色、我的页浅色；选中色统一取主题色
            ShiWanJuTheme(dark = vm.screen == "layout") {
                LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show(); vm.message = null } }
                if (vm.screen == "layout") LayoutScreen(vm) else MyScreen(vm)
            }
        }
    }
}
