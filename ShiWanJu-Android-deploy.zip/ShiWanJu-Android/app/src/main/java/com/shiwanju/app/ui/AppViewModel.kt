package com.shiwanju.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.shiwanju.app.data.*
import com.shiwanju.app.engine.PreviewEngine
import com.shiwanju.app.engine.TextUtil
import org.json.JSONObject

const val COPY_POOL_SIZE = 80   // 足够覆盖 数量(≤15) × 倍率(≤5)
const val IMG_POOL_SIZE = 20

/** 全局状态与业务动作（排版页 + 我的页共用同一份数据）。 */
class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var data by mutableStateOf(store.loadData()); private set
    var ui by mutableStateOf(store.loadUi()); private set
    var previewHtml by mutableStateOf(""); private set

    // ---- 非持久化的界面状态 ----
    var screen by mutableStateOf("layout")          // layout / my
    var editing by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var showTitle by mutableStateOf(false)
    var charCount by mutableIntStateOf(0)
    var anchorLabel by mutableStateOf(DEFAULT_ANCHOR_LABEL)
    var titleText by mutableStateOf("")
    var hasTitle by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var textViewMode by mutableStateOf(store.textViewMode); private set

    /** 由预览 WebView 注册：执行一段 JS */
    var js: ((String) -> Unit)? = null
    var pendingScroll: String? = null
    private var lastTitle = ""

    val layoutIndex get() = PreviewEngine.layoutIndex(data, ui)
    val kind get() = layoutKindOf(data.layout.getOrNull(layoutIndex)?.name)
    val margins: List<Int> get() = PreviewEngine.margins(ui, kind)

    init { validateSelections(); rebuild() }

    // ------------------------------------------------------------------ 基础

    private fun rebuild() { previewHtml = PreviewEngine.render(data, ui) }

    /** 修改界面状态并重新渲染预览 */
    private fun updateUi(block: UiState.() -> UiState) { ui = ui.block(); store.saveUi(ui); rebuild() }
    /** 修改界面状态，但不重新渲染（编辑中的内容不会被覆盖） */
    private fun updateUiQuiet(block: UiState.() -> UiState) { ui = ui.block(); store.saveUi(ui) }

    /** 修改数据（来自“我的”页）：保存、校验已选内容、刷新预览 */
    fun updateData(block: (AppData) -> AppData) {
        data = block(data)
        store.saveData(data)
        validateSelections()
        rebuild()
    }

    fun toast(msg: String) { message = msg }

    // ------------------------------------------------------------------ 随机读取

    private fun drawCopy(m: TextModule?): List<String> =
        if (m == null) emptyList() else TextUtil.sampleN(TextUtil.splitLines(m.content), COPY_POOL_SIZE)

    private fun drawImagePool(): Pair<String?, List<String>> {
        val mods = data.files.image.filter { TextUtil.imageUrls(it.content).isNotEmpty() }
        if (mods.isEmpty()) return null to emptyList()
        val m = mods.random()
        return m.id to TextUtil.sampleN(TextUtil.imageUrls(m.content), IMG_POOL_SIZE)
    }

    /** 数据变化后，校验已选内容仍然存在（与 Web 版 validateSelections 一致） */
    private fun validateSelections() {
        var u = ui
        val cm = data.files.text.firstOrNull { it.id == u.copyModuleId }
        u = if (cm == null) u.copy(copyModuleId = null, copyLines = emptyList())
        else {
            val cur = TextUtil.splitLines(cm.content).toSet()
            var lines = u.copyLines.filter { it in cur }
            if (lines.isEmpty()) lines = drawCopy(cm)
            u.copy(copyLines = lines)
        }
        val im = data.files.image.firstOrNull { it.id == u.imgModuleId }
        val urls = im?.let { TextUtil.imageUrls(it.content).toSet() } ?: emptySet()
        var pool = u.imgPool.filter { it in urls }
        var imgId = u.imgModuleId
        if (pool.isEmpty()) { val (id, p) = drawImagePool(); imgId = id; pool = p }
        u = u.copy(imgModuleId = imgId, imgPool = pool)
        if (data.files.gif.none { it.id == u.gifId }) u = u.copy(gifId = null, gifContent = "")
        val hids = u.historyIds.filter { id -> data.history.any { it.id == id } }
        u = u.copy(historyIds = hids, mediaOrder = if (hids.isEmpty()) u.mediaOrder.filter { it != "history" } else u.mediaOrder)
        ui = u
        store.saveUi(ui)
    }

    // ------------------------------------------------------------------ 排版页动作

    fun switchTab(tab: String) { updateUiQuiet { copy(tab = tab) } }
    fun selectAccount(id: String) = updateUi { copy(accountId = id) }
    fun selectLayout(id: String) = updateUi { copy(layoutId = id) }
    fun setQuantity(n: Int) { if (n > 0) updateUi { copy(quantity = n) } }
    fun cycleMultiplier() = updateUi { copy(multiplier = (multiplier % 5) + 1) }
    fun selectTextCat(cat: String) = updateUiQuiet { copy(textCat = cat) }

    /** 选中文案名称；再次点击同一名称 = 重新随机读取 */
    fun selectCopyModule(id: String) {
        val m = data.files.text.firstOrNull { it.id == id } ?: return
        updateUi { copy(copyModuleId = id, copyLines = drawCopy(m)) }
        if (showTitle) loadRandomTitle()   // 标题跟随所选文案
    }

    fun rerollImages() { val (id, p) = drawImagePool(); updateUi { copy(imgModuleId = id, imgPool = p) } }

    fun setMoreCat(c: String) = updateUiQuiet { copy(moreCat = c) }

    private fun randomBlock(content: String?): String =
        (content ?: "").split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }.let { if (it.isEmpty()) "" else it.random() }

    fun applyRandomEmoji() {
        val item = data.emoji.randomOrNull() ?: return toast("暂无emoji条目，请到【我的】-更多-emoji中添加")
        val v = randomBlock(item.content)
        if (v.isEmpty()) return toast("所选emoji条目没有可用内容")
        updateUi { copy(previewEmoji = v) }
    }

    /** 点击动图条目：随机取其中一段插入预览；先点先插入 */
    fun pickGif(item: FileItem) {
        val v = randomBlock(item.content)
        if (v.isEmpty()) return toast("该动图条目没有可用素材")
        pendingScroll = "gif"
        updateUi { copy(gifId = item.id, gifContent = v, mediaOrder = if ("gif" in mediaOrder) mediaOrder else mediaOrder + "gif") }
    }

    /** 往期：每次随机读取 5 条 */
    fun rollHistory() {
        if (data.history.isEmpty()) return toast("暂无往期条目，请到【我的】-更多-往期中添加")
        pendingScroll = "history"
        val ids = TextUtil.sampleN(data.history, 5).map { it.id }
        updateUi { copy(historyIds = ids, mediaOrder = if ("history" in mediaOrder) mediaOrder else mediaOrder + "history") }
    }

    fun clearHistory() = updateUi { copy(historyIds = emptyList(), mediaOrder = mediaOrder.filter { it != "history" }) }

    // ------------------------------------------------------------------ 编辑模式 / 悬浮窗

    fun toggleEditing() {
        editing = !editing
        if (editing) { loadRandomTitle(); showTitle = true } else { showTitle = false; showSettings = false }
        js?.invoke("setEditing($editing)")
    }

    /** 往期 / 动图共用边距：index 0..3 = 上右下左；实时作用到预览，不重新渲染 */
    fun setMargin(index: Int, value: Int) {
        val arr = margins.toMutableList()
        arr[index] = value.coerceAtLeast(0)
        val key = kind.ifEmpty { "default" }
        updateUiQuiet { copy(margins = this.margins + (key to arr)) }
        js?.invoke("setMargins(${arr[0]},${arr[1]},${arr[2]},${arr[3]})")
    }

    /** 全局空行：以光标所在行为基准；还没点选任何行时不生效 */
    fun toggleBlank(top: Boolean) {
        if (ui.anchorPath == null) { anchorLabel = DEFAULT_ANCHOR_LABEL; return }
        updateUiQuiet { if (top) copy(blankTop = !blankTop) else copy(blankBottom = !blankBottom) }
        js?.invoke("setBlank(${ui.blankTop},${ui.blankBottom})")
    }

    // 来自预览 WebView 的回调
    fun onAnchor(path: String?, label: String) {
        anchorLabel = label
        if (path != ui.anchorPath) updateUiQuiet { copy(anchorPath = path) }
    }

    /** 随机文章标题：跟随当前所选文案；以单个换行符分割，剔除空行 */
    fun loadRandomTitle() {
        val sel = data.files.text.firstOrNull { it.id == ui.copyModuleId }
        val mods = if (sel != null) listOf(sel) else data.files.text.filter { it.category == ui.textCat }
        val titles = mods.flatMap { TextUtil.splitSingleLines(it.title) }
        if (titles.isEmpty()) {
            titleText = if (mods.size == 1) "所选文案「${mods[0].name}」暂无标题，请到【我的】-文案中填写标题。" else "暂无标题，请先选择文案，并到【我的】-文案中填写标题。"
            lastTitle = ""; hasTitle = false; return
        }
        var pick = titles.random()
        if (titles.size > 1) { var g = 0; while (pick == lastTitle && g++ < 10) pick = titles.random() }
        lastTitle = pick; titleText = pick; hasTitle = true
    }

    // ------------------------------------------------------------------ 我的页：数据增删改

    fun saveAccount(a: Account) = updateData { d ->
        val i = d.accounts.indexOfFirst { it.id == a.id }
        d.copy(accounts = if (i >= 0) d.accounts.toMutableList().also { it[i] = a } else d.accounts + a)
    }
    fun deleteAccount(id: String) = updateData { d -> d.copy(accounts = d.accounts.filter { it.id != id }) }

    fun saveText(m: TextModule) = updateData { d ->
        val l = d.files.text; val i = l.indexOfFirst { it.id == m.id }
        d.copy(files = d.files.copy(text = if (i >= 0) l.toMutableList().also { it[i] = m } else l + m))
    }
    fun deleteText(id: String) = updateData { d -> d.copy(files = d.files.copy(text = d.files.text.filter { it.id != id })) }
    fun reorderText(from: Int, to: Int) = updateData { d ->
        val l = d.files.text.toMutableList()
        if (from in l.indices && to in l.indices && from != to) { val x = l.removeAt(from); l.add(to, x) }
        d.copy(files = d.files.copy(text = l))
    }

    /** kind = gif / image */
    fun saveFile(kind: String, f: FileItem) = updateData { d ->
        val l = if (kind == "gif") d.files.gif else d.files.image
        val i = l.indexOfFirst { it.id == f.id }
        val nl = if (i >= 0) l.toMutableList().also { it[i] = f } else l + f
        d.copy(files = if (kind == "gif") d.files.copy(gif = nl) else d.files.copy(image = nl))
    }
    fun deleteFile(kind: String, id: String) = updateData { d ->
        d.copy(files = if (kind == "gif") d.files.copy(gif = d.files.gif.filter { it.id != id }) else d.files.copy(image = d.files.image.filter { it.id != id }))
    }

    fun saveLayout(x: LayoutItem) = updateData { d ->
        val i = d.layout.indexOfFirst { it.id == x.id }
        d.copy(layout = if (i >= 0) d.layout.toMutableList().also { it[i] = x } else d.layout + x)
    }
    fun deleteLayout(id: String) = updateData { d -> d.copy(layout = d.layout.filter { it.id != id }) }

    fun saveEmoji(x: EmojiItem) = updateData { d ->
        val i = d.emoji.indexOfFirst { it.id == x.id }
        d.copy(emoji = if (i >= 0) d.emoji.toMutableList().also { it[i] = x } else d.emoji + x)
    }
    fun deleteEmoji(id: String) = updateData { d -> d.copy(emoji = d.emoji.filter { it.id != id }) }

    fun saveHistory(x: HistoryEntry) = updateData { d ->
        val i = d.history.indexOfFirst { it.id == x.id }
        d.copy(history = if (i >= 0) d.history.toMutableList().also { it[i] = x } else d.history + x)
    }
    fun deleteHistory(id: String) = updateData { d -> d.copy(history = d.history.filter { it.id != id }) }

    fun newId(): String = System.currentTimeMillis().toString()

    fun setTextViewMode(mode: String) { store.textViewMode = mode; textViewMode = store.textViewMode }

    // ------------------------------------------------------------------ 备份

    fun exportJson(): String = store.exportJson(data)

    fun importJson(json: String): Boolean {
        val d = store.parseBackup(json) ?: return false
        updateData { d }
        return true
    }

    companion object {
        const val DEFAULT_ANCHOR_LABEL = "请在预览中点击一行文字，作为插入空行的基准行"
        fun parseAnchor(json: String): Pair<String?, String> {
            val o = JSONObject(json)
            val path = if (o.isNull("path")) null else o.getJSONArray("path").toString()
            return path to o.optString("label", DEFAULT_ANCHOR_LABEL)
        }
    }
}
