package com.shiwanju.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** 主题色填充的小按钮 / 标签（选中态）；未选中为描边深色底 */
@Composable
fun ThemeChip(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    dark: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(8.dp)
    val bg = if (selected) AppColors.Theme else if (dark) AppColors.Field else Color.White
    val fg = if (selected) AppColors.OnTheme else if (dark) AppColors.TextMain else AppColors.MyText
    Box(
        modifier = modifier
            .clip(shape)
            .background(bg)
            .border(BorderStroke(1.dp, if (selected) AppColors.Theme else if (dark) AppColors.Line else AppColors.MyLine), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, maxLines = 1) }
}

/**
 * 数字步进输入框：直接输入 + ▲▼ 微调。
 * 激活时清空原有内容；失焦为空则恢复原值；输入即实时回调。
 */
@Composable
fun Stepper(value: Int, onValue: (Int) -> Unit, modifier: Modifier = Modifier) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    var prev by remember { mutableStateOf(value.toString()) }
    val shape = RoundedCornerShape(6.dp)
    Row(
        modifier = modifier.height(32.dp).clip(shape).background(AppColors.Field).border(1.dp, AppColors.Line, shape),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = text,
            onValueChange = { v ->
                val d = v.filter { it.isDigit() }.take(4)
                text = d
                d.toIntOrNull()?.let(onValue)
            },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            cursorBrush = SolidColor(AppColors.Theme),
            modifier = Modifier
                .width(52.dp)
                .onFocusChanged { f ->
                    if (f.isFocused) { prev = text; text = "" }
                    else if (text.isEmpty()) text = prev
                }
        )
        Column(Modifier.width(26.dp).fillMaxHeight().background(Color(0xFF2A2A2A))) {
            StepBtn("▲", Modifier.weight(1f)) { val n = ((text.toIntOrNull() ?: prev.toIntOrNull() ?: 0) + 1).coerceAtLeast(0); text = n.toString(); prev = text; onValue(n) }
            StepBtn("▼", Modifier.weight(1f)) { val n = ((text.toIntOrNull() ?: prev.toIntOrNull() ?: 0) - 1).coerceAtLeast(0); text = n.toString(); prev = text; onValue(n) }
        }
    }
}

@Composable
private fun StepBtn(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxWidth().clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Color(0xFFCCCCCC), fontSize = 8.sp)
    }
}

/**
 * 悬浮窗：可拖拽（拖标题栏）、可缩放（拖右下角）；点到哪个窗口由 onTouch 通知置顶。
 * bounds 为可活动范围（像素），位置与尺寸都被限制在范围内。
 */
@Composable
fun FloatingWindow(
    title: String,
    initialX: Dp, initialY: Dp, initialW: Dp, initialH: Dp,
    boundsW: Float, boundsH: Float,
    onClose: () -> Unit,
    onTouch: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val density = LocalDensity.current
    val minW = with(density) { 190.dp.toPx() }
    val minH = with(density) { 96.dp.toPx() }
    var x by remember { mutableFloatStateOf(with(density) { initialX.toPx() }) }
    var y by remember { mutableFloatStateOf(with(density) { initialY.toPx() }) }
    var w by remember { mutableFloatStateOf(with(density) { initialW.toPx() }) }
    var h by remember { mutableFloatStateOf(with(density) { initialH.toPx() }) }

    // 范围变化（旋转 / 键盘）时收回到可见区域
    val cw = w.coerceIn(minOf(minW, boundsW), maxOf(minOf(minW, boundsW), boundsW - 8f))
    val ch = h.coerceIn(minOf(minH, boundsH), maxOf(minOf(minH, boundsH), boundsH - 8f))
    val cx = x.coerceIn(0f, maxOf(0f, boundsW - cw))
    val cy = y.coerceIn(0f, maxOf(0f, boundsH - ch))
    val shape = RoundedCornerShape(12.dp)

    Box(
        Modifier
            .offset { IntOffset(cx.roundToInt(), cy.roundToInt()) }
            .size(with(density) { cw.toDp() }, with(density) { ch.toDp() })
            .clip(shape)
            .background(AppColors.Panel)
            .border(1.dp, AppColors.Theme.copy(alpha = 0.45f), shape)
            .pointerInput(Unit) { awaitEachGesture { awaitFirstDown(requireUnconsumed = false); onTouch() } }
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(36.dp)
                    .background(AppColors.Theme.copy(alpha = 0.10f))
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            x = (cx + drag.x).coerceIn(0f, maxOf(0f, boundsW - cw))
                            y = (cy + drag.y).coerceIn(0f, maxOf(0f, boundsH - ch))
                        }
                    }
                    .padding(start = 12.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = AppColors.Theme, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Box(Modifier.size(32.dp).clickable(onClick = onClose), contentAlignment = Alignment.Center) { Text("✕", color = Color(0xFFAAAAAA), fontSize = 15.sp) }
            }
            Column(Modifier.weight(1f).fillMaxWidth().padding(10.dp), content = content)
        }
        Box(
            Modifier.align(Alignment.BottomEnd).size(28.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        w = (cw + drag.x).coerceIn(minOf(minW, boundsW - cx), boundsW - cx)
                        h = (ch + drag.y).coerceIn(minOf(minH, boundsH - cy), boundsH - cy)
                    }
                },
            contentAlignment = Alignment.BottomEnd
        ) { Text("◢", color = AppColors.Theme.copy(alpha = 0.75f), fontSize = 14.sp, modifier = Modifier.padding(end = 4.dp, bottom = 2.dp)) }
    }
}
