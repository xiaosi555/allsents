package com.shiwanju.app.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.shiwanju.app.data.*
import com.shiwanju.app.engine.PreviewEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** 「我的」：首页 / 账号 / 文案 / 版式 / 更多 / 备份。浅色，选中态一律用主题色填充。 */
@Composable
fun MyScreen(vm: AppViewModel) {
    var route by remember { mutableStateOf("home") }
    BackHandler { if (route == "home") vm.screen = "layout" else route = "home" }

    Column(Modifier.fillMaxSize().background(AppColors.MyBg).systemBarsPadding()) {
        val title = when (route) { "accounts" -> "账号"; "texts" -> "文案"; "layouts" -> "版式管理"; "more" -> "更多"; "backup" -> "备份"; else -> "我的" }
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (route == "home") vm.screen = "layout" else route = "home" }) {
                Text("‹ " + if (route == "home") "排版" else "我的", color = AppColors.MyText, fontSize = 16.sp)
            }
            Text(title, Modifier.weight(1f), color = AppColors.MyText, fontSize = 17.sp, fontWeight = FontWeight.Medium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.width(64.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (route) {
                "accounts" -> AccountsPage(vm)
                "texts" -> TextsPage(vm)
                "layouts" -> LayoutsPage(vm)
                "more" -> MorePage(vm)
                "backup" -> BackupPage(vm)
                else -> HomePage(vm) { route = it }
            }
        }
    }
}

// ---------------------------------------------------------------------- 通用

@Composable
private fun Card(onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(AppColors.MyCard)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(14.dp),
        content = content
    )
}

@Composable
private fun ListRow(name: String, summary: String, onClick: () -> Unit) {
    Card(onClick) {
        Text(name, color = AppColors.MyText, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (summary.isNotEmpty()) Text(summary, color = Color(0xFF9CA3AF), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

private fun summarize(t: String, max: Int = 60) = t.replace(Regex("\\s+"), " ").trim().let { if (it.length > max) it.take(max) + "…" else it }

@Composable
private fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable
private fun Empty(text: String) = Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { Text(text, color = Color(0xFF9CA3AF), fontSize = 13.sp) }

@Composable
private fun TopActions(content: @Composable RowScope.() -> Unit) =
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically, content = content)

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit, lines: Int = 1, hint: String = "") {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, placeholder = { if (hint.isNotEmpty()) Text(hint) },
        modifier = Modifier.fillMaxWidth(), minLines = lines, maxLines = if (lines == 1) 1 else 12, singleLine = lines == 1
    )
}

/** 统一的编辑弹窗：保存 / 取消，可选删除 */
@Composable
private fun EditDialog(title: String, onDismiss: () -> Unit, onSave: () -> Unit, onDelete: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp), content = content) },
        confirmButton = { TextButton(onClick = onSave) { Text("保存", color = AppColors.MyText, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("删除", color = Color(0xFFDC2626)) }
                TextButton(onClick = onDismiss) { Text("取消", color = AppColors.MyDim) }
            }
        }
    )
}

@Composable
private fun ConfirmDelete(what: String, onOk: () -> Unit, onCancel: () -> Unit) = AlertDialog(
    onDismissRequest = onCancel, title = { Text("确认删除") }, text = { Text("确定要删除该$what 吗？") },
    confirmButton = { TextButton(onClick = onOk) { Text("删除", color = Color(0xFFDC2626)) } },
    dismissButton = { TextButton(onClick = onCancel) { Text("取消") } }
)

/** 选中项填充主题色的标签栏 */
@Composable
private fun TabBar(tabs: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White)) {
        tabs.forEach { (k, label) ->
            val on = k == selected
            Box(
                Modifier.weight(1f).height(44.dp).background(if (on) AppColors.Theme else Color.Transparent).clickable { onSelect(k) },
                contentAlignment = Alignment.Center
            ) { Text(label, color = if (on) AppColors.OnTheme else AppColors.MyDim, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium) }
        }
    }
}

// ---------------------------------------------------------------------- 首页

@Composable
private fun HomePage(vm: AppViewModel, go: (String) -> Unit) = Page {
    val d = vm.data
    ListRow("账号", "已配置 ${d.accounts.size} 个账号") { go("accounts") }
    ListRow("文案", "共 ${d.files.text.size} 个文案模块") { go("texts") }
    ListRow("版式", "已保存 ${d.layout.size} 个版式") { go("layouts") }
    ListRow("更多", "共 ${d.emoji.size + d.history.size + d.files.gif.size + d.files.image.size} 个数据模块") { go("more") }
    ListRow("备份", "导出 / 导入全部数据") { go("backup") }
}

// ---------------------------------------------------------------------- 账号

@Composable
private fun AccountsPage(vm: AppViewModel) = Page {
    var edit by remember { mutableStateOf<Account?>(null) }
    var isNew by remember { mutableStateOf(false) }
    TopActions { ThemeChip("+ 新增账号", true, dark = false) { edit = Account(id = vm.newId()); isNew = true } }
    if (vm.data.accounts.isEmpty()) Empty("暂无数据，请点击右上角新增")
    vm.data.accounts.forEach { a -> ListRow(a.name, a.author.ifEmpty { a.appId }) { edit = a; isNew = false } }

    edit?.let { a ->
        var avatar by remember(a.id) { mutableStateOf(a.avatar) }; var name by remember(a.id) { mutableStateOf(a.name) }
        var appId by remember(a.id) { mutableStateOf(a.appId) }; var secret by remember(a.id) { mutableStateOf(a.secret) }
        var mp by remember(a.id) { mutableStateOf(a.mpAvatar) }; var author by remember(a.id) { mutableStateOf(a.author) }
        var confirm by remember { mutableStateOf(false) }
        EditDialog(if (isNew) "新增账号" else "编辑账号", { edit = null },
            { vm.saveAccount(a.copy(avatar = avatar, name = name.ifEmpty { "未命名账号" }, appId = appId, secret = secret, mpAvatar = mp, author = author)); edit = null },
            if (isNew) null else ({ confirm = true })) {
            Field("微信头像链接（朋友圈版头像取自这里）", avatar, { avatar = it }); Field("账号名称", name, { name = it })
            Field("AppID", appId, { appId = it }); Field("AppSecret", secret, { secret = it })
            Field("公众号头像", mp, { mp = it }); Field("作者", author, { author = it })
        }
        if (confirm) ConfirmDelete("账号", { vm.deleteAccount(a.id); confirm = false; edit = null }, { confirm = false })
    }
}

// ---------------------------------------------------------------------- 文案（宫格 / 列表、排序）

@Composable
private fun TextsPage(vm: AppViewModel) = Page {
    var edit by remember { mutableStateOf<TextModule?>(null) }
    var isNew by remember { mutableStateOf(false) }
    var sorting by remember { mutableStateOf(false) }
    val grid = vm.textViewMode == "grid"
    val list = vm.data.files.text

    TopActions {
        ThemeChip(if (grid) "列表" else "宫格", false, dark = false) { vm.setTextViewMode(if (grid) "list" else "grid") }   // 视图模式持久化，直到下次切换
        Spacer(Modifier.width(8.dp))
        ThemeChip(if (sorting) "完成" else "排序", sorting, dark = false) { sorting = !sorting }
        if (!sorting) { Spacer(Modifier.width(8.dp)); ThemeChip("+ 新建模块", true, dark = false) { edit = TextModule(id = vm.newId(), category = "名句"); isNew = true } }
    }
    if (sorting) Text("按住右侧 ≡ 上下拖动调整顺序，松手自动保存", color = Color(0xFF9CA3AF), fontSize = 12.sp)
    if (list.isEmpty()) Empty("暂无模块，请点击右上角新建")

    fun summary(m: TextModule) = "【${m.category}】" + summarize(m.content)
    when {
        sorting -> SortableList(list, { from, to -> vm.reorderText(from, to) })        // 排序模式统一用列表呈现
        grid -> list.chunked(4).forEach { row ->                                      // 宫格：4 列（4*n）
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { m ->
                    Column(
                        Modifier.weight(1f).heightIn(min = 64.dp).clip(RoundedCornerShape(12.dp)).background(AppColors.MyCard)
                            .clickable { edit = m; isNew = false }.padding(horizontal = 4.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(m.name, color = AppColors.MyText, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(summarize(m.content, 24), color = Color(0xFF9CA3AF), fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        else -> list.forEach { m -> ListRow(m.name, summary(m)) { edit = m; isNew = false } }
    }

    edit?.let { m ->
        var name by remember(m.id) { mutableStateOf(m.name) }; var title by remember(m.id) { mutableStateOf(m.title) }
        var content by remember(m.id) { mutableStateOf(m.content) }; var cat by remember(m.id) { mutableStateOf(m.category) }
        var confirm by remember { mutableStateOf(false) }
        EditDialog(if (isNew) "新建文案模块" else "编辑文案模块", { edit = null },
            { vm.saveText(m.copy(name = name.ifEmpty { "未命名模块" }, title = title, content = content, category = cat)); edit = null },
            if (isNew) null else ({ confirm = true })) {
            Field("名称", name, { name = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { TEXT_CATEGORIES.forEach { c -> ThemeChip(c, cat == c, dark = false) { cat = c } } }
            Field("标题（每行一个，用于随机标题）", title, { title = it }, 3)
            Field("内容（每行一条；含“——出处”的会按版式输出出处）", content, { content = it }, 6)
        }
        if (confirm) ConfirmDelete("文案模块", { vm.deleteText(m.id); confirm = false; edit = null }, { confirm = false })
    }
}

/** 手动排序：每行固定高度，拖动 ≡ 上下移动，松手后按位移换算新位置并保存 */
@Composable
private fun SortableList(items: List<TextModule>, onMove: (Int, Int) -> Unit) {
    val rowH = 72.dp
    val rowPx = with(LocalDensity.current) { rowH.toPx() }
    var dragging by remember { mutableIntStateOf(-1) }
    var dy by remember { mutableFloatStateOf(0f) }
    Column {
        items.forEachIndexed { i, m ->
            Row(
                Modifier.fillMaxWidth().height(rowH).padding(vertical = 4.dp)
                    .zIndex(if (i == dragging) 1f else 0f)
                    .graphicsLayer { translationY = if (i == dragging) dy else 0f; shadowElevation = if (i == dragging) 24f else 0f }
                    .clip(RoundedCornerShape(12.dp)).background(AppColors.MyCard),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(m.name, color = AppColors.MyText, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                    Text("【${m.category}】" + summarize(m.content, 30), color = Color(0xFF9CA3AF), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box(
                    Modifier.width(56.dp).fillMaxHeight().pointerInput(i, items.size) {
                        detectDragGestures(
                            onDragStart = { dragging = i; dy = 0f },
                            onDrag = { c, d -> c.consume(); dy += d.y },
                            onDragEnd = {
                                val to = (i + (dy / rowPx).roundToInt()).coerceIn(0, items.lastIndex)
                                dragging = -1; dy = 0f
                                if (to != i) onMove(i, to)
                            },
                            onDragCancel = { dragging = -1; dy = 0f }
                        )
                    },
                    contentAlignment = Alignment.Center
                ) { Text("≡", color = Color(0xFF9CA3AF), fontSize = 22.sp) }
            }
        }
    }
}

// ---------------------------------------------------------------------- 版式

@Composable
private fun LayoutsPage(vm: AppViewModel) = Page {
    var edit by remember { mutableStateOf<LayoutItem?>(null) }
    var isNew by remember { mutableStateOf(false) }
    TopActions { ThemeChip("+ 新增", true, dark = false) { edit = LayoutItem(id = vm.newId()); isNew = true } }
    if (vm.data.layout.isEmpty()) Empty("暂无数据，请点击右上角新增")
    vm.data.layout.forEach { l -> ListRow(l.name, summarize(l.content)) { edit = l; isNew = false } }

    edit?.let { l ->
        var name by remember(l.id) { mutableStateOf(l.name) }; var content by remember(l.id) { mutableStateOf(l.content) }
        var confirm by remember { mutableStateOf(false) }
        EditDialog(if (isNew) "新增版式" else "详情与编辑", { edit = null },
            { vm.saveLayout(l.copy(name = name.ifEmpty { "未命名配置" }, content = content)); edit = null },
            if (isNew) null else ({ confirm = true })) {
            Text("名称需含 朋友圈 / 文字断句 / 卡片 / 断章序引 之一，才会套用对应的出处、倍率、头像规则", color = AppColors.MyDim, fontSize = 12.sp)
            Field("配置名称", name, { name = it }); Field("模板代码（HTML）", content, { content = it }, 10)
        }
        if (confirm) ConfirmDelete("版式", { vm.deleteLayout(l.id); confirm = false; edit = null }, { confirm = false })
    }
}

// ---------------------------------------------------------------------- 更多：emoji / 往期 / 动图 / 配图

@Composable
private fun MorePage(vm: AppViewModel) {
    var tab by remember { mutableStateOf("emoji") }
    var editKey by remember { mutableStateOf<String?>(null) }     // 正在编辑条目的 id；"new" 表示新增
    val tabs = listOf("emoji" to "emoji", "history" to "往期", "gif" to "动图", "image" to "配图")

    Column(Modifier.fillMaxSize()) {
        TabBar(tabs, tab) { tab = it; editKey = null }
        Page {
            val label = when (tab) { "emoji" -> "已有 Emoji 列表"; "history" -> "已有往期推荐列表"; "gif" -> "动图模块列表 (代码块)"; else -> "配图模块列表 (资源链接)" }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = AppColors.MyDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
                ThemeChip(if (tab == "emoji") "+ 新增 Emoji" else if (tab == "history") "+ 新增往期" else "+ 新建模块", true, dark = false) { editKey = "new" }
            }
            when (tab) {
                "emoji" -> vm.data.emoji.forEach { e -> ListRow(e.name, summarize(e.content)) { editKey = e.id } }
                "history" -> vm.data.history.forEach { h -> ListRow(h.title.ifEmpty { h.name }, h.link.ifEmpty { h.image }.ifEmpty { summarize(h.content) }) { editKey = h.id } }
                "gif" -> vm.data.files.gif.forEach { f -> ListRow(f.name, summarize(f.content)) { editKey = f.id } }
                else -> vm.data.files.image.forEach { f -> ListRow(f.name, summarize(f.content)) { editKey = f.id } }
            }
            val empty = when (tab) { "emoji" -> vm.data.emoji.isEmpty(); "history" -> vm.data.history.isEmpty(); "gif" -> vm.data.files.gif.isEmpty(); else -> vm.data.files.image.isEmpty() }
            if (empty) Empty("暂无数据，请点击右上角新增")
        }
    }

    val key = editKey ?: return
    val isNew = key == "new"
    var confirm by remember(key) { mutableStateOf(false) }
    val close = { editKey = null }
    when (tab) {
        "emoji" -> {
            val cur = vm.data.emoji.firstOrNull { it.id == key } ?: EmojiItem(id = vm.newId())
            var name by remember(key) { mutableStateOf(cur.name) }; var content by remember(key) { mutableStateOf(cur.content) }
            EditDialog(if (isNew) "新增配置" else "详情与编辑", close, { vm.saveEmoji(cur.copy(name = name.ifEmpty { "未命名配置" }, content = content)); close() }, if (isNew) null else ({ confirm = true })) {
                Field("配置名称", name, { name = it }); Field("内容（多个 emoji 之间用空行分隔，随机取一个）", content, { content = it }, 4)
            }
            if (confirm) ConfirmDelete("配置", { vm.deleteEmoji(cur.id); confirm = false; close() }, { confirm = false })
        }
        "history" -> {
            val cur = vm.data.history.firstOrNull { it.id == key } ?: HistoryEntry(id = vm.newId())
            var title by remember(key) { mutableStateOf(cur.title.ifEmpty { cur.name }) }
            var link by remember(key) { mutableStateOf(cur.link) }; var image by remember(key) { mutableStateOf(cur.image) }
            EditDialog(if (isNew) "新增往期" else "详情与编辑", close, {
                // 保存标题 / 链接 / 图片三项；content 为按模板生成的渲染代码（有图片=图片版，无图片=文字版）
                val t = title.trim(); val l = link.trim(); val im = image.trim()
                vm.saveHistory(cur.copy(name = t.ifEmpty { "未命名配置" }, title = t, link = l, image = im, content = PreviewEngine.historyEntryHtml(t.ifEmpty { "未命名配置" }, l, im))); close()
            }, if (isNew) null else ({ confirm = true })) {
                Field("标题", title, { title = it }); Field("链接", link, { link = it }); Field("图片（留空为文字版）", image, { image = it })
            }
            if (confirm) ConfirmDelete("配置", { vm.deleteHistory(cur.id); confirm = false; close() }, { confirm = false })
        }
        else -> {
            val isGif = tab == "gif"
            val cur = (if (isGif) vm.data.files.gif else vm.data.files.image).firstOrNull { it.id == key } ?: FileItem(id = vm.newId())
            var name by remember(key) { mutableStateOf(cur.name) }; var content by remember(key) { mutableStateOf(cur.content) }
            EditDialog(if (isNew) "新建模块" else "编辑模块", close, { vm.saveFile(tab, cur.copy(name = name.ifEmpty { "未命名模块" }, content = content)); close() }, if (isNew) null else ({ confirm = true })) {
                Field("名称", name, { name = it })
                Field(if (isGif) "内容（按两个换行分隔，随机取一段）" else "内容（每行一个图片地址，可省略 https://）", content, { content = it }, 8)
            }
            if (confirm) ConfirmDelete("模块", { vm.deleteFile(tab, cur.id); confirm = false; close() }, { confirm = false })
        }
    }
}

// ---------------------------------------------------------------------- 备份

@Composable
private fun BackupPage(vm: AppViewModel) = Page {
    val ctx: Context = LocalContext.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray(Charsets.UTF_8)) } }.isSuccess
            vm.toast(if (ok) "备份已导出" else "导出失败")
        }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } }.getOrNull()
            vm.toast(if (text != null && vm.importJson(text)) "备份恢复成功！全部设置项已写入对应配置。" else "备份文件格式不正确，导入失败。")
        }
    }
    Card {
        Text("一键导出", color = AppColors.MyText, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text("导出为 JSON，格式与网页版完全一致，可互相导入。", color = AppColors.MyDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        ThemeChip("导出全部数据", true, dark = false) { export.launch("my_admin_backup_${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}.json") }
    }
    Card {
        Text("导入恢复", color = AppColors.MyText, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text("导入会覆盖当前全部数据（账号、文案、版式、更多）。", color = AppColors.MyDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        ThemeChip("选择备份文件", false, dark = false) { import.launch(arrayOf("application/json", "text/plain", "*/*")) }
    }
}
