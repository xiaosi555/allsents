package com.shiwanju.app.ui

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONObject

/** 预览页 → 原生 的回调通道（字数、空行基准行）。 */
class PreviewBridge(
    private val charsCb: (Int) -> Unit,
    private val anchorCb: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    @JavascriptInterface fun onChars(n: Int) { main.post { charsCb(n) } }
    @JavascriptInterface fun onAnchor(json: String) { main.post { anchorCb(json) } }
}

/**
 * 预览区域：WebView 只负责渲染公众号 HTML 与富文本选中 / 编辑；
 * 所有排版逻辑（文案、配图、出处、倍率、间距、往期、动图）都由原生的 PreviewEngine 生成。
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewWebView(vm: AppViewModel, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var loaded by remember { mutableStateOf(false) }

    val webView = remember {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.setSupportZoom(false)
            setBackgroundColor(Color.WHITE)
            addJavascriptInterface(
                PreviewBridge(
                    charsCb = { vm.charCount = it },
                    anchorCb = { json -> runCatching { AppViewModel.parseAnchor(json) }.getOrNull()?.let { (p, l) -> vm.onAnchor(p, l) } }
                ), "Android"
            )
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) { loaded = true }
            }
            loadUrl("file:///android_asset/preview.html")
        }
    }

    DisposableEffect(webView) {
        vm.js = { script -> webView.evaluateJavascript(script, null) }
        onDispose { vm.js = null; webView.destroy() }
    }

    // 每次预览 HTML 变化（选文案 / 选版式 / 倍率 / 数据变化…）都整体重绘；编辑中的内容会被覆盖（与 Web 版一致）
    LaunchedEffect(loaded, vm.previewHtml) {
        if (!loaded) return@LaunchedEffect
        val anchor = vm.ui.anchorPath?.let { JSONObject.quote(it) } ?: "null"
        webView.evaluateJavascript("setContent(${JSONObject.quote(vm.previewHtml)}, $anchor, ${vm.ui.blankTop}, ${vm.ui.blankBottom})", null)
        vm.pendingScroll?.let { kind ->
            webView.evaluateJavascript("scrollToBlock('$kind')", null)
            vm.pendingScroll = null
        }
    }

    AndroidView(factory = { webView }, modifier = modifier)
}
