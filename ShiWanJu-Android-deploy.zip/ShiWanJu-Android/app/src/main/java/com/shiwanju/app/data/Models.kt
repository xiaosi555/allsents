package com.shiwanju.app.data

/**
 * 数据模型。字段名与 Web 版备份 JSON 完全一致，Web 版导出的备份可直接导入，反之亦然。
 * 所有字段都带默认值（Gson 反序列化缺字段时保持默认）。id 统一用 String（Web 版的数字 id 会被自动转成字符串）。
 */
data class Account(
    val id: String = "",
    val avatar: String = "",      // 微信头像链接（朋友圈版头像取自这里）
    val name: String = "",
    val appId: String = "",
    val secret: String = "",
    val mpAvatar: String = "",
    val author: String = ""
)

data class LayoutItem(val id: String = "", val name: String = "", val content: String = "")

/** 文案模块：content 每行一条；title 每行一个随机标题；category 为 朋友圈 / 名句 */
data class TextModule(
    val id: String = "",
    val name: String = "",
    val title: String = "",
    val content: String = "",
    val category: String = "朋友圈"
)

/** 配图 / 动图条目：content 为按“两个换行”分隔的素材（动图随机取一段；配图每行一个图片地址） */
data class FileItem(val id: String = "", val name: String = "", val title: String = "", val content: String = "")

/** 往期条目：标题 / 链接 / 图片；content 为按模板生成的渲染代码（兼容旧数据） */
data class HistoryEntry(
    val id: String = "",
    val name: String = "",
    val content: String = "",
    val title: String = "",
    val link: String = "",
    val image: String = ""
)

data class EmojiItem(val id: String = "", val name: String = "", val content: String = "")

data class Files(
    val image: List<FileItem> = emptyList(),
    val text: List<TextModule> = emptyList(),
    val gif: List<FileItem> = emptyList()
)

data class AppData(
    val accounts: List<Account> = emptyList(),
    val layout: List<LayoutItem> = emptyList(),
    val history: List<HistoryEntry> = emptyList(),
    val emoji: List<EmojiItem> = emptyList(),
    val files: Files = Files(),
    val layoutVer: Int = 0
)

/** 排版页的界面状态（对应 Web 版 sessionStorage 里的 ui），会持久化。 */
data class UiState(
    val tab: String = "copy",                      // account / layout / copy / image / more
    val layoutId: String? = null,
    val quantity: Int = 9,
    val accountId: String? = null,
    val textCat: String = "朋友圈",
    val copyModuleId: String? = null,
    val copyLines: List<String> = emptyList(),     // 随机读取的文案池（最多 80 条）
    val imgModuleId: String? = null,
    val imgPool: List<String> = emptyList(),       // 随机读取的配图池（最多 20 张）
    val moreCat: String = "emoji",                 // emoji / gif / history
    val gifId: String? = null,
    val gifContent: String = "",                   // 随机取到的那一段动图代码
    val historyIds: List<String> = emptyList(),    // 随机读取的 5 条往期
    val mediaOrder: List<String> = emptyList(),    // 动图 / 往期的点击先后顺序：gif / history
    val multiplier: Int = 1,                       // 倍率 x1~x5
    val margins: Map<String, List<Int>> = emptyMap(), // 往期/动图共用边距（上右下左），按版式种类记忆
    val blankTop: Boolean = false,
    val blankBottom: Boolean = false,
    val anchorPath: String? = null,                // 全局空行的基准行（JSON 数组路径）
    val previewEmoji: String = ""
)

const val LAYOUT_VER = 2
val TEXT_CATEGORIES = listOf("朋友圈", "名句")

fun layoutKindOf(name: String?): String {
    val n = name ?: ""
    return when {
        n.contains("卡片") -> "card"
        Regex("断章|序引").containsMatchIn(n) -> "duan"
        n.contains("朋友圈") -> "moments"
        n.contains("断句") -> "sentence"
        else -> ""
    }
}
