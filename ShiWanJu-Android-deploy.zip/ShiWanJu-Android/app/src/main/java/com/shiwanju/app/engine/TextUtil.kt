package com.shiwanju.app.engine

import kotlin.random.Random

/** 文本 / 地址处理工具（与 Web 版逻辑一一对应）。 */
object TextUtil {
    private val LINE_SPLIT = Regex("\\r?\\n+")
    fun splitLines(c: String?): List<String> = (c ?: "").split(LINE_SPLIT).map { it.trim() }.filter { it.isNotEmpty() }

    /** 按单个换行符分割并剔除空行（随机标题的读取规则） */
    fun splitSingleLines(c: String?): List<String> = (c ?: "").split("\n").map { it.replace("\r", "").trim() }.filter { it.isNotEmpty() }

    fun pad2(n: Int) = n.toString().padStart(2, '0')
    fun charLen(s: String?) = (s ?: "").let { it.codePointCount(0, it.length) }

    fun <T> sampleN(list: List<T>, n: Int, rnd: Random = Random.Default): List<T> = list.shuffled(rnd).take(maxOf(0, n))

    fun esc(s: String?): String = (s ?: "")
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")

    // ---------- 配图地址规范化 ----------
    private val SRC_RE = Regex("(?:src\\s*=\\s*[\"']|\\]\\()\\s*([^\"'\\s)]+)", RegexOption.IGNORE_CASE)
    private val TRIM_RE = Regex("^[\\s\"'“”‘’(<\\[]+|[\\s\"'“”‘’)>\\],;，。]+$")
    private val DOMAIN_RE = Regex("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/|$)")

    /** 支持 http(s) / 协议相对(//) / 省略协议的域名(如 shturl.cc/xxx) / data:image / <img src> / Markdown 图片 */
    fun normImgUrl(line: String?): String {
        var u = (line ?: "").trim()
        if (u.isEmpty()) return ""
        SRC_RE.find(u)?.let { u = it.groupValues[1] }
        u = u.replace(TRIM_RE, "")
        return when {
            u.startsWith("data:image/", ignoreCase = true) -> u
            u.startsWith("//") -> "https:$u"
            Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(u) -> u
            DOMAIN_RE.containsMatchIn(u) -> "https://$u"
            else -> ""
        }
    }
    fun imageUrls(content: String?): List<String> = splitLines(content).map { normImgUrl(it) }.filter { it.isNotEmpty() }

    // ---------- “正文 —— 出处” ----------
    data class Parsed(val body: String, val source: String, val idx: Int = 0)

    private val SRC1 = Regex("^(.*\\S)\\s*(?:—{2,}|―{2,}|－{2,}|-{2,}|─{2,})\\s*(.+)$")
    private val SRC2 = Regex("^(.*\\S)\\s*[—―－-]\\s*([^—―－-]*《.+)$")

    /** 破折号（——/—/―/--）之后的短文本（≤40 字）视为出处；单个破折号仅在后面带《书名》时才算 */
    fun parseSource(line: String?): Parsed {
        val s = (line ?: "").trim()
        val m = SRC1.find(s) ?: SRC2.find(s)
        if (m != null && m.groupValues[2].trim().length <= 40) return Parsed(m.groupValues[1].trim(), m.groupValues[2].trim())
        return Parsed(s, "")
    }
}
