package com.shiwanju.app.engine

import org.jsoup.nodes.Element

/** 行内 style 的读写（保持属性顺序，支持 !important，括号 / 引号内的分号不会被拆开）。 */
object Css {
    fun parse(style: String?): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        val s = style ?: return out
        val parts = ArrayList<String>()
        val sb = StringBuilder()
        var depth = 0
        var quote: Char? = null
        for (ch in s) {
            when {
                quote != null -> { sb.append(ch); if (ch == quote) quote = null }
                ch == '"' || ch == '\'' -> { quote = ch; sb.append(ch) }
                ch == '(' -> { depth++; sb.append(ch) }
                ch == ')' -> { depth = maxOf(0, depth - 1); sb.append(ch) }
                ch == ';' && depth == 0 -> { parts.add(sb.toString()); sb.setLength(0) }
                else -> sb.append(ch)
            }
        }
        if (sb.isNotBlank()) parts.add(sb.toString())
        for (p in parts) {
            val i = p.indexOf(':')
            if (i <= 0) continue
            out[p.substring(0, i).trim().lowercase()] = p.substring(i + 1).trim()
        }
        return out
    }

    fun write(el: Element, map: Map<String, String>) {
        el.attr("style", map.entries.joinToString(";") { "${it.key}:${it.value}" } + if (map.isEmpty()) "" else ";")
    }

    fun set(el: Element, prop: String, value: String, important: Boolean = false) {
        val m = parse(el.attr("style"))
        m[prop.lowercase()] = value + if (important) " !important" else ""
        write(el, m)
    }

    fun style(el: Element): String = el.attr("style")

    fun has(el: Element, re: Regex): Boolean = re.containsMatchIn(el.attr("style"))
}
