package com.shiwanju.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** 全局主题色（对应 Web 版 --theme / --theme-on）。所有选中态、强调色都从这里派生。 */
object AppColors {
    val Theme = Color(0xFFCCFF00)
    val OnTheme = Color(0xFF000000)

    // 排版页（深色）
    val Bg = Color(0xFF121212)
    val Panel = Color(0xFF1B1B1B)
    val Field = Color(0xFF222222)
    val Line = Color(0xFF333333)
    val TextMain = Color(0xFFDDDDDD)
    val TextDim = Color(0xFF888888)

    // 我的页（浅色）
    val MyBg = Color(0xFFF7F7F7)
    val MyCard = Color(0xFFFFFFFF)
    val MyText = Color(0xFF111827)
    val MyDim = Color(0xFF6B7280)
    val MyLine = Color(0xFFE5E7EB)
}

@Composable
fun ShiWanJuTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = AppColors.Theme, onPrimary = AppColors.OnTheme,
        background = AppColors.Bg, surface = AppColors.Panel, onSurface = AppColors.TextMain
    ) else lightColorScheme(
        primary = AppColors.Theme, onPrimary = AppColors.OnTheme,
        background = AppColors.MyBg, surface = AppColors.MyCard, onSurface = AppColors.MyText
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
