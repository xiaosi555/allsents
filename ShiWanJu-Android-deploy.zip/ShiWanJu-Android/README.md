# 拾万句 · Android 原生版

用 Kotlin + Jetpack Compose 重新实现的「拾万句」排版工具，功能与网页版一一对应（需求见同目录的《拾万句_需求说明书.html》）。

## 运行

1. 用 Android Studio（Koala / 2024.1 及以上）打开本目录，等待 Gradle 同步（需要联网下载依赖）。
2. 选择真机或模拟器（Android 8.0 / API 26 及以上），点击 Run。

> 注意：本工程是在没有 Android SDK 的环境里编写的，**没有经过编译和真机测试**。首次同步 / 编译时如遇到版本或语法告警，按 Android Studio 提示微调即可；引擎逻辑逐函数对应网页版，出问题时可对照需求说明书排查。

## 结构

```
app/src/main
├── assets
│   ├── seed.json          首次启动的示例数据（已清除 AppID / AppSecret）
│   ├── templates.json     四个版式的最新模板代码（条目间距 25px、朋友圈图片正方形等）
│   └── preview.html       预览页壳（WebView 只负责渲染与富文本选中 / 编辑）
└── java/com/shiwanju/app
    ├── data      Models（数据模型，字段与网页版备份一致）· Store（本地持久化、备份解析、规范化）
    ├── engine    PreviewEngine（排版引擎，Jsoup）· TextUtil · Css
    └── ui        AppViewModel · LayoutScreen（排版页）· MyScreens（我的）· PreviewWebView · Components · Theme
```

## 与网页版的差异

- 「导出」按钮（原来只弹提示）改为：把当前预览以富文本 HTML 复制到剪贴板。
- 「我的-文案」排序模式统一用列表呈现（网页版宫格下也可拖拽）。
- 版式详情页没有实时预览框（只编辑名称与模板代码）。
- 主题色固定为 #CCFF00，常量集中在 `ui/Theme.kt`。
- 数据与网页版备份 JSON 互通：网页版导出的文件可在「我的-备份」导入，反之亦然。
